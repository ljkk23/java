package GeometricObject;

public interface Colorable {
    public abstract void howToColor();
}
