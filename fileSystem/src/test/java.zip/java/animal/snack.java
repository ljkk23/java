package animal;

    public class snack implements Animal {

        public void cry() {
            System.out.println("嘶嘶嘶");
        }

        public String getAnimalName(){
            return "蛇";
        }
    }
