package animal;

public interface Animal {
	void cry();
	String getAnimalName();
}